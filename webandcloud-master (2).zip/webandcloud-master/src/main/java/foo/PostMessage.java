package foo;

public class PostMessage {
	public String owner;
	public String body;
	public String url;
	
	public PostMessage() {}
}
