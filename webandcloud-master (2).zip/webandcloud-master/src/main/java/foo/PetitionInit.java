package foo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;

import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.EntityNotFoundException;
import com.google.appengine.api.datastore.FetchOptions;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.KeyRange;
import com.google.appengine.api.datastore.PreparedQuery;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Query.FilterOperator;
import com.google.appengine.api.datastore.Query.FilterPredicate;

@WebServlet(name = "PetInit", urlPatterns = { "/petitionInit" })
public class PetitionInit extends HttpServlet {

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String id_user;
		response.setContentType("text/html");
		response.setCharacterEncoding("UTF-8");

		Random r = new Random();
		DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

		// Create users
		for (int i = 0; i < 50; i++) {
			for (int j = 0; j < 10; j++) {
				Entity e = new Entity("User", "id" + i + "_" +j);
				e.setProperty("nom", "mon nom est " + j);
				e.setProperty("prenom", "mon prénom est " + j);
				e.setProperty("email", "mon adresse mail est " + j);
				datastore.put(e);
				response.getWriter().print("<li> created user:" + e.getKey() + "<br>");
				// creer une petition
				int nbMaxPetition = r.nextInt(5);
				for(int k=0; k<nbMaxPetition; k++) {
					Entity p = new Entity("Petition", "id" + i + "_" +j + "_"+ k);
					p.setProperty("theme", "le theme est " + j);
					p.setProperty("titre", "titre: " + j);
					p.setProperty("description", "description: " + j);
					p.setProperty("date", "date: " + j);
					p.setProperty("proprietaire", "id" + i + "_" +j);
					// signer une petition
					HashSet<String> listSignataire = new HashSet<String>();
					while (listSignataire.size() < 50) {
						id_user="id" + r.nextInt(50) + "_" + r.nextInt(10);
						if(!listSignataire.contains(id_user)) {
						listSignataire.add(id_user);
						response.getWriter().print("<li> signataire : " + id_user + "<br>");
						}
					}
					p.setProperty("signataire", listSignataire);
					
					datastore.put(p);
					response.getWriter().print("<li> created petition:" + p.getKey() + "<br>");
				}
			}
		}
	}

}
