package foo;

public class RandomResult {
	public Integer result;
	
	public RandomResult(int i) {
		this.result=new Integer(i);
	}
}
